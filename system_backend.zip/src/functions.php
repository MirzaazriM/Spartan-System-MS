<?php
// converts Traversable into an array
function a(...$args): array { return $args; }
<?php
/**
 * Created by PhpStorm.
 * User: mirza
 * Date: 7/26/18
 * Time: 12:04 PM
 */

namespace Model\Mapper;


use Component\DataMapper;

class DownloadMapper extends DataMapper
{

}
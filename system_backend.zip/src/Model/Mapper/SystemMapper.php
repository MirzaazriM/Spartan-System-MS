<?php
/**
 * Created by PhpStorm.
 * User: mirza
 * Date: 6/28/18
 * Time: 9:03 AM
 */

namespace Model\Mapper;

use PDO;
use PDOException;
use Component\DataMapper;
use Model\Entity\Language;
use Model\Entity\LanguageCollection;
use Model\Entity\Shared;

class SystemMapper extends DataMapper
{


}